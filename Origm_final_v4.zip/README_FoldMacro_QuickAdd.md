# 📘 FoldMacro QuickAdd ガイド

![Origmロゴ](/docs/assets/Origm.png)

本Vaultは、fold_macroテンプレートをQuickAddスクリプトで扱うための統合システムです。

---

## 📚 Foldテンプレ サンプル構成一覧

| fold_type      | テンプレファイル名             | 対応Zettel                       | 対応Canvas                        |
|----------------|--------------------------------|----------------------------------|-----------------------------------|
| contradiction  | contradiction_template.md      | contradiction_example_zettel.md | fold_macro_contradiction.canvas  |
| bridge         | bridge_template.md             | bridge_intro_zettel.md          | fold_macro_bridge.canvas         |
| simlog         | simlog_example_template.md     | simlog_sample_01.md             | fold_macro_simlog_combined.canvas |
