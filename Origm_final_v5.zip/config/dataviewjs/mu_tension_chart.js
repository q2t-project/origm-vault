// μテンション推移チャート（DataviewJS）
const pages = dv.pages('"zettel/simlog"')
  .filter(p => p.mu_tension)
  .sort(p => p.date, 'asc');

const labels = pages.map(p => p.file.name);
const data = pages.map(p => p.mu_tension);

dv.paragraph("μテンションチャート");

window.renderChart({
  type: 'line',
  data: {
    labels: labels,
    datasets: [{
      label: 'μテンション',
      data: data
    }]
  },
  options: {
    responsive: true,
    scales: {
      y: { beginAtZero: true }
    }
  }
});
